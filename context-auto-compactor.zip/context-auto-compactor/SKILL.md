---
name: context-auto-compactor
description: 把"高频词/短语→单字符"的确定性词典压缩做成透明请求拦截层，让长对话/长文档在每轮调用模型前自动压缩上下文、调用后自动还原，对调用方无感。当用户说"自动压缩上下文""做成自动拦截层""每轮自动省 token""把上下文压缩做成中间件"或希望长对话不被上下文窗口拖垮、又不想每轮手动触发时使用。提供可运行的 `scripts/auto_compactor.py`（含离线 dry-run 演示，支持中英文混合），也支持接入真实 OpenAI 兼容客户端。
agent_created: true
---

# 上下文自动压缩拦截层

## Overview

本技能是「context-compactor（手动 Skill）」的自动版：把同一条确定性词典压缩思路做成**透明中间件**。每次对话轮次，它在底层自动完成"用全量历史重建字典 → 压缩除最近 N 条用户消息外的所有历史 → 把映射表拼进 system 消息 → 发送 → 存原文"，调用方仍照常调用 `chat()`，完全无感。历史越滚越大，压缩省得越多。

- 适用：多轮长对话、长文档问答等上下文会持续膨胀的场景。
- 不适用：超短对话（字典成本摊不薄）、要求逐字保真的场景（压缩会引入符号映射）。

## Workflow

### Step 1: 确定接入方式
- **离线演示 / 快速验证**：直接运行脚本看效果，无需 API key。
- **接入真实客户端**：把 `AutoCompactSession` 的 `transport` 设为 `openai_client.chat.completions.create`，之后用 `sess.chat(...)` 代替原来的 `client.chat.completions.create(...)`。

### Step 2: 运行（离线演示）
```bash
python scripts/auto_compactor.py --rounds 6
```
脚本会跑一个多轮对话，逐轮打印「字典条数 / 原文历史 token / 实际发送 token / 节省比例」，并显示 system 消息里的映射表。预期曲线：前几轮字典未摊薄为负，第 3 轮起转正并随历史增长（实测 6 轮中文累计省 ~42%）。

### Step 3: 接入真实客户端
```python
from openai import OpenAI
from auto_compactor import AutoCompactSession

client = OpenAI()
sess = AutoCompactSession(transport=client.chat.completions.create)
sess.system = "你是一个助手"
reply = sess.chat("用户的第一句话", model="gpt-4o")   # 内部自动压缩后发送
```
`keep_raw` 控制最近几条用户消息保持原文（让模型在完整文本上推理新问题）；`cjk_max` 控制中文最大词长（默认 12，以捕获整段重复短语）；`top` 控制字典条数上限。

### Step 4: 查看收益
调用 `sess.stats()` 取 `{"dict_size", "history_tokens", "sent_tokens", "saved", "saved_pct"}`，用于上报实际节省。

### 进阶：复用 Skill A（手动 Skill）产出的固定词典（推荐给稳定术语库）

默认每轮从全量历史"重建"字典，适合语料随对话自然生长的场景；但当领域有一批**稳定术语/专有名词**时，更优做法是先用 Skill A（context-compactor）在语料上生成一份映射表，直接喂给本拦截层"固定使用"——字典不再每轮变动，稳定、最省、最稳。

两种加载方式：

```python
# 方式一：构造时传入（字符串路径会被自动解析）
sess = AutoCompactSession(predefined_dict="dict.txt")   # 固定字典，每轮不重建

# 方式二：运行时加载
sess.load_dictionary("dict.txt")
```

`dict.txt` 即 Skill A 输出的图例（`{符号} = {短语}` 一行一条）；也支持 `.json`（自动识别 `{短语: 符号}` 与 `{符号: 短语}` 两种方向）。

- **固定字典模式**（`allow_grow=False`，默认）：字典恒等于预置内容，跨轮完全一致；适合术语库长期不变。
- **补词模式**（`allow_grow=True`）：以预置字典为种子，每轮再自动发现并追加少量新高频词（上限受 `top` 约束），兼顾稳定与自适应。

> 离线验证（4 轮中文，仅 4 条预置词条）：固定字典模式稳定保持 4 条、累计省 ~16%；补词模式追加 4 条、累计省 ~28%。预置词典越全，覆盖越高。

接收的词典文件格式示例（图例文本，注释头/空行自动忽略，含压缩正文也不影响）：
```
Dictionary (expand symbols before use):
§ = 大型语言模型
¶ = 上下文窗口
◆ = 训练数据
● = 神经网络
```

## 关键约束（与手动版一致，自动版额外注意）
1. **替换符必须单 token**：脚本已用 tokenizer 逐字符校验，只取 1-token 符号。
2. **词典成本要摊销**：自动版靠"历史增长"摊薄图例成本；短对话勿用。
3. **最近用户消息保持原文**：`keep_raw` 默认 1，避免压缩当前问题影响推理。
4. **字典一致性**：同一会话字典由全量历史重建，天然一致；不要中途切换语料来源导致字典语义漂移。
5. **解压依赖模型能力**：映射表放进 system 消息，模型据此还原；关键场景保留原文或做解压校验。
6. **CJK 选词已知限制**：整句重复时可能残留少量相邻滑动窗碎片（已用 4 字重叠守卫缓解）；真实场景多为术语，字典干净。

## 与其他方案的关系
与「滑窗 / RAG / 摘要」互补：高频术语走符号映射（确定性、可逆、零额外推理），低频大块内容仍靠 RAG/摘要兜底。本拦截层专注于"每轮自动、对调用方透明"这一目标。

## 实现说明
`scripts/auto_compactor.py` 内：`build_mapping` 统计中英文 n-gram 频率 → 按收益降序、**非重叠 + 4 字重叠守卫**筛选 → 分配 1-token 符号；`AutoCompactSession._outgoing` 重建字典并压缩历史；`DryRunTransport` 提供无需联网的演示传输层。详见脚本内注释。
