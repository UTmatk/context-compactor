---
name: context-compactor
description: 压缩长文本 / 对话历史 / 提示词的 token 占用，用单字符符号替换高频词与短语（确定性词典编码），在发送给模型前显著缩减上下文。当用户说"压缩上下文""省 token""把这段对话/文档压缩一下""context 太大了""token 超限"或希望缩减长文 token 数时使用。提供可运行的压缩脚本，支持中英文混合，输出压缩文本与映射表，并报告压缩率与回本轮数。
agent_created: true
---

# 上下文压缩（确定性词典编码）

## Overview

把长文本里高频出现的多 token 短语（英文词组、中文词串）映射成单 token 符号，前置一份只发一次的映射表（图例），从而缩减发送给模型的 token 数。与 LLMLingua 这类"软"压缩不同，本方法是**确定性、可逆**的：固定映射，随时可精确还原。

- 适用：多轮长对话历史、长文档、术语 / 专有名词 / 代码标识符高频重复的文本。
- 不适用：短文本、低频重复、创意生成（压缩会伤表达）。

## Workflow

### Step 1: 确定输入
获取用户要压缩的内容——文件路径（`--input file`）或直接粘贴的文本（从 stdin 读）。

### Step 2: 运行压缩脚本
执行 `scripts/compact.py`：

```bash
# 处理文件并查看统计
python scripts/compact.py --input long.txt --output packed.txt --stats

# 管道处理
cat long.txt | python scripts/compact.py --stats
```

关键参数：
- `--top N`：最多映射条数（默认 15）
- `--max-ngram`：英文词组最大词数（默认 3）
- `--cjk-min` / `--cjk-max`：中文词串长度区间（默认 2~6 字）
- `--no-legend`：省略映射表表头（当你自行管理映射表时）
- `--stats`：向 stderr 打印原始 / 压缩 / 映射表 token 数与节省比例

### Step 3: 查看报告
脚本输出：原始 token、压缩后正文、映射表成本、总节省比例、回本轮数（盈亏平衡点）。

### Step 4: 交付压缩结果
把"映射表 + 压缩正文"作为新上下文发给模型。若多轮复用，映射表只放一次（建议进 system prompt / 长期记忆），后续轮次只发符号版历史。

### 进阶：把映射表导出给「自动拦截层」复用
本 Skill 产出的图例（`{符号} = {短语}` 一行一条）可直接作为「context-auto-compactor」（方案 B）的预置词典，实现"手动建词库 + 自动套用"：
```bash
# 先在领域大语料上压一次，取映射表存成 dict.txt（从 --stats 的 dictionary 段落复制图例）
python scripts/compact.py --input corpus.txt --stats
```
```python
from auto_compactor import AutoCompactSession
sess = AutoCompactSession(predefined_dict="dict.txt")   # 固定词典，每轮不重建
```
A 负责在语料上产出高质量词典，B 负责每轮透明套用。**注意：不要**把 A、B 串联在同一段文本上做双重压缩。

## 关键约束（实现与使用时必须遵守）

1. **替换符必须单 token**：脚本已用 tokenizer 逐字符校验，只选 1-token 符号；请勿手改符号池。
2. **词典成本要摊销**：映射表本身占 token，仅在术语高频重复时划算；`--stats` 的"回本轮数"即盈亏平衡点。
3. **非重叠选择**：长短语已覆盖的子串不再入选，避免浪费槽位。
4. **只压历史、不压当前问题**：让模型在完整文本上推理新问题，过去轮次才存压缩版。
5. **词典一致性**：同一段会话映射表保持一致，中途不要改。
6. **解压**：模型需能还原符号；关键场景保留原文或做解压校验。

## 实现说明

`build_mapping` 统计中英文 n-gram 频率 → 按 `次数 × (原 token 数 − 1)` 收益降序 → 非重叠贪心筛选（跳过子串、跳过收益不抵图例成本的条目）→ 分配经校验的 1-token 符号 → `compress` 最长优先替换。详见 `scripts/compact.py` 内注释。

> 精准计数需安装 `tiktoken`（`pip install tiktoken`）；未安装时脚本退化为 ~4 字符/token 的近似计数，仅供示意。

## 与其他方案的关系

确定性、可逆，优于摘要压缩的可预测性；但压不掉"低频但占地方"的内容，那种仍靠摘要 / RAG 兜底。实战与滑窗、RAG 组合：高频术语走符号映射，长文档走检索。
