#!/usr/bin/env python3
"""context-compactor: deterministic dictionary compression for prompts.

Maps high-frequency phrases (English word groups or CJK character runs) to
single-token symbols so a long text / conversation history fits in fewer tokens
before being sent to a model. Deterministic and reversible (unlike LLM-based
"soft" compression): the mapping is a fixed table that can be expanded exactly.

Usage:
    python compact.py --input long.txt --output packed.txt --stats
    cat long.txt | python compact.py --stats
"""
import re
import sys
import argparse
from collections import Counter

try:
    import tiktoken
    ENC = tiktoken.get_encoding("cl100k_base")
    def n_tokens(s: str) -> int:
        return len(ENC.encode(s))
    HAVE_TOK = True
except Exception:
    HAVE_TOK = False
    def n_tokens(s: str) -> int:          # crude proxy: ~4 chars per token
        return max(1, len(s) // 4)


# Pool of candidate symbols. Only those that encode to exactly 1 token are used
# (verified at runtime); many emoji are multi-token and are skipped automatically.
CANDIDATES = "§¶▪◆●★☆♠♣♥♦⬡⬢◼◻⬣▲▼◀▶♀♂☀☂☎☘♪♫☯☮✝✡⚡🔥❄⚙⚘⚛⚜⬧⬨❖✪✿"


def latin_words(text):
    return re.findall(r"[A-Za-z0-9]+(?:['’][A-Za-z]+)*", text)


def cjk_runs(text):
    return re.findall(r"[一-鿿]+", text)


def latin_ngrams(words, max_n):
    counts = {}
    n = len(words)
    for k in range(1, max_n + 1):
        for i in range(n - k + 1):
            phrase = " ".join(words[i:i + k])
            counts[phrase] = counts.get(phrase, 0) + 1
    return counts


def cjk_ngrams(run, min_l, max_l):
    counts = {}
    L = len(run)
    for k in range(min_l, max_l + 1):
        for i in range(L - k + 1):
            phrase = run[i:i + k]
            counts[phrase] = counts.get(phrase, 0) + 1
    return counts


def is_subphrase(cand, chosen):
    # latin phrases carry spaces, CJK do not; cross-type never matches.
    return cand in chosen


def pick_symbols(n):
    out = []
    for ch in CANDIDATES:
        if n_tokens(ch) == 1:        # only 1-token symbols actually compress
            out.append(ch)
        if len(out) >= n:
            break
    return out


def compress(text, mapping):
    # longest phrases first so inner phrases are not double-replaced
    for phrase in sorted(mapping, key=len, reverse=True):
        sym = mapping[phrase]
        if re.search(r"[A-Za-z0-9]", phrase):
            rx = r"(?<!\w)" + re.escape(phrase) + r"(?!\w)"
            text = re.sub(rx, sym, text)
        else:
            text = text.replace(phrase, sym)
    return text


def build_mapping(text, top, max_ngram, cjk_min, cjk_max):
    # Counter (not dict) so per-run CJK counts accumulate instead of overwriting
    counts = Counter()
    counts.update(latin_ngrams(latin_words(text), max_ngram))
    for run in cjk_runs(text):
        counts.update(cjk_ngrams(run, cjk_min, cjk_max))

    raw = []
    for phrase, cnt in counts.items():
        tlen = n_tokens(phrase)
        if tlen < 2 or cnt < 2:          # 1-token or single-occurrence: no gain
            continue
        saving = cnt * (tlen - 1)         # assume 1-token replacement
        raw.append((saving, cnt, tlen, phrase))
    raw.sort(reverse=True)                # biggest savers first

    chosen = []
    for saving, cnt, tlen, phrase in raw:
        if any(is_subphrase(phrase, cp) for _, _, _, cp in chosen):
            continue                      # already covered by a longer entry
        if saving <= n_tokens("x = " + phrase):
            continue                      # cannot earn its own dictionary slot
        chosen.append((saving, cnt, tlen, phrase))
        if len(chosen) >= top:
            break

    syms = pick_symbols(len(chosen))
    mapping = {}
    legend = []
    legend_tok = 0
    for (saving, cnt, tlen, phrase), sym in zip(chosen, syms):
        mapping[phrase] = sym
        line = f"{sym} = {phrase}"
        legend.append(line)
        legend_tok += n_tokens(line)
    return mapping, legend, legend_tok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", help="input file (default: stdin)")
    ap.add_argument("--output", help="write compressed text here (default: stdout)")
    ap.add_argument("--top", type=int, default=15, help="max mapping entries")
    ap.add_argument("--max-ngram", type=int, default=3, help="max English phrase length (words)")
    ap.add_argument("--cjk-min", type=int, default=2, help="min CJK phrase length (chars)")
    ap.add_argument("--cjk-max", type=int, default=6, help="max CJK phrase length (chars)")
    ap.add_argument("--no-legend", action="store_true", help="omit the dictionary header")
    ap.add_argument("--stats", action="store_true", help="print stats to stderr")
    args = ap.parse_args()

    if args.input:
        with open(args.input, encoding="utf-8") as f:
            text = f.read()
    else:
        text = sys.stdin.read()

    mapping, legend, legend_tok = build_mapping(
        text, args.top, args.max_ngram, args.cjk_min, args.cjk_max)
    compressed = compress(text, mapping)

    legend_text = ""
    if legend and not args.no_legend:
        legend_text = "Dictionary (expand symbols before use):\n" + "\n".join(legend) + "\n\n"
    out = legend_text + compressed

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out)
    else:
        sys.stdout.write(out)

    if args.stats:
        orig = n_tokens(text)
        comp = n_tokens(compressed)
        total = n_tokens(out)
        per = orig - comp
        be = (legend_tok / per) if per > 0 else float("inf")
        sys.stderr.write("tokenizer : " + ("tiktoken cl100k_base" if HAVE_TOK else "proxy (~4c/tok)") + "\n")
        sys.stderr.write(f"original tokens   : {orig}\n")
        sys.stderr.write(f"compressed body   : {comp}\n")
        sys.stderr.write(f"dictionary tokens : {legend_tok} (sent once)\n")
        sys.stderr.write(f"total with dict   : {total}\n")
        sys.stderr.write(f"tokens saved      : {orig - total} ({100*(orig-total)/orig:.1f}%)\n")
        if be != float("inf"):
            sys.stderr.write(f"break-even turns  : {be:.2f}\n")
        sys.stderr.write("dictionary:\n")
        for l in legend:
            sys.stderr.write("  " + l + "\n")


if __name__ == "__main__":
    main()
